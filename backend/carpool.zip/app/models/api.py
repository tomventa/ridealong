from typing import NamedTuple, Dict, List, Optional, Any, Union
from pydantic import BaseModel, Field, constr
from datetime import date

# General purpose
class Point(NamedTuple):
    x: int
    y: int


# Account
class UtentePubblico(BaseModel):
  id: int
  nome: str
  cognome: str
  data_di_nascita: Union[date, None] = None
  data_di_registrazione: Union[date, None] = None
  email: str
  cellulare: str

class Utente(UtentePubblico):
  token_email: str
  token_cellulare: str
  abilitato: bool
  password: str
  email_verificata: bool
  cellulare_verificato: bool

class RegistrazioneUtente(BaseModel):
  nome: str
  cognome: str
  email: str
  cellulare: str
  password: str
  data_di_nascita: Union[date, None] = None
  
class FeedbackForm(BaseModel):
  per_utente: int
  codice_tratta: int
  stelle_generale: int
  stelle_tempistiche: int
  stelle_autista: int
  stelle_veicolo: int
  stelle_esperienza_complessiva: int
  stelle_sicurezza_alla_guida: int
  segnala_percorso_non_ottimale: bool = False
  recensione: str


class Feedback(FeedbackForm):
  id: int
  codice_utente: int
  risposta: str
  data_feedback: date
  data_risposta: Union[date, None] = None

class FeedbackReply(BaseModel):
  id: int
  risposta: str

class Autista(Utente):
   enabled_as_driver: bool
   date_of_enable_as_driver: int
   date_of_next_review: int

class TipoDocumento(BaseModel):
  document_type_id: int
  name: str
  description: str
  front_required: bool = True
  back_required: bool = True
  has_expiry: bool = False
  has_photo: bool = False
  is_valid_as_id: bool = True


class Documento(TipoDocumento):
  document_id: int
  user_id: int
  document_type: int
  upload_date: int
  revision_date: int
  verified: bool = False
  user_notes: Union[str, None]
  admin_notes: Union[str, None]
  original_filename: Union[str, None]

class RegistroPosizione(BaseModel):
  id: int
  user_id: int
  date: int
  long: float
  lat: float
  accuracy: float = 20

class Veicolo(BaseModel):
  vin: str
  plate: str
  user_id: int
  brand: str
  model: str
  immatriulation_date: int
  upload_date: int
  description: str
  seats: int = 5
  is_eletric: bool = False
  displacement: int = 0
  power: int = 11
  date_next_maintenance: int
  date_expire_insurance: int


# Generic / Other
class Success(BaseModel):
  success: bool
  notes: Union[None, str]
  error: Union[None, str]
