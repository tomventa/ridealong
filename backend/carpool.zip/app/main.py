from fastapi import FastAPI, Depends, WebSocket
from fastapi.middleware.cors import CORSMiddleware
from fastapi.logger import logger
from .routers import account, feedback


description="""
### Backend server for the Ridealong school project!
"""


app = FastAPI(
    title="API for Ridealong",
    description=description,
    version="1.7.6",
    contact={
      "name": "Tommaso Ventafridda",
      "url": "https://github.com/tomventa/ridealong"
    },
)


# During development, the webserver runs on a separate origin
# therefore a CORS configuration on the api server is required.
# In production the api server will be behind the same
# reverse-proxy serving the static website, so there won't be any CORS issue
origins = [
    "http://carpool.local",
    "http://pctom2.route3.ipv4.dcforwarder.local.dns.tomh.it",
    "http://localhost",
    "http://localhost:3000",
    "http://localhost:8080",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(account.router)
app.include_router(feedback.router)
#app.include_router(websocket.router)
#app.include_router(carwash.router)
#app.include_router(box.router)
# activate here other imported routes
